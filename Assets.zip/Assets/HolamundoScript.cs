using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HolamundoScript : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}

public class HolaMundoScript : MonoBehaviour
{
    void Start()
    {
        
        Debug.Log("Hola mundo");
    }
}
